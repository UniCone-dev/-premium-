# Desert Order Icons

An Egyptian gold desert-themed icon pack for KDE Plasma / Linux desktops —
apps, mimetypes, folders, devices, actions and status icons, all in a
consistent gold-on-bronze badge style.

Part of the **Desert Order** project.

Created by **rudr** — [github.com/UniCone-dev](https://github.com/UniCone-dev)

## Install

```bash
mkdir -p ~/.local/share/icons
cd ~/.local/share/icons
unzip DesertOrderIcons.zip
kbuildsycoca6 --noincremental
```

Then: **System Settings → Appearance → Icons → DesertOrderIcons → Apply**.

Icons this pack doesn't cover fall back to Breeze Dark automatically
(`Inherits=breeze-dark` in `index.theme`), so nothing will appear broken.

## License

MIT — see [LICENSE](LICENSE). Free to use and modify; please keep the
copyright notice and credit "rudr / UniCone-dev" in derivative work.
