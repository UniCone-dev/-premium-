import QtQuick 2.5
import org.kde.plasma.core 2.0 as PlasmaCore

Rectangle {
    id: root
    property int stage
    property int stages: 6

    onStageChanged: {
        if (stage == 1) introAnim.start()
    }

    width: 1280
    height: 800
    color: "#0c0906"

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#241a0e" }
            GradientStop { position: 0.6; color: "#120c07" }
            GradientStop { position: 1.0; color: "#050301" }
        }
    }

    Repeater {
        model: 40
        Rectangle {
            id: ember
            property real startX: Math.random() * root.width
            width: 2 + Math.random()*2
            height: width
            radius: width/2
            color: "#ff9a45"
            opacity: 0
            x: startX
            y: root.height + Math.random()*200

            SequentialAnimation {
                loops: Animation.Infinite
                running: true
                PauseAnimation { duration: Math.random()*4000 }
                ParallelAnimation {
                    NumberAnimation { target: ember; property: "y"; to: -20; duration: 6000 + Math.random()*4000; easing.type: Easing.Linear }
                    NumberAnimation { target: ember; property: "x"; to: ember.startX + (Math.random()*120-60); duration: 6000 + Math.random()*4000 }
                    SequentialAnimation {
                        NumberAnimation { target: ember; property: "opacity"; to: 0.8; duration: 800 }
                        PauseAnimation { duration: 4000 }
                        NumberAnimation { target: ember; property: "opacity"; to: 0; duration: 1500 }
                    }
                }
            }
        }
    }

    Item {
        id: emblem
        width: 150; height: 150
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -110

        Rectangle {
            id: glowBack
            anchors.centerIn: parent
            width: 170; height: 170
            radius: 85
            color: "#00000000"
            SequentialAnimation on opacity {
                loops: Animation.Infinite
                NumberAnimation { to: 0.35; duration: 1800; easing.type: Easing.InOutQuad }
                NumberAnimation { to: 0.7; duration: 1800; easing.type: Easing.InOutQuad }
            }
        }

        Rectangle {
            anchors.centerIn: parent
            width: 96; height: 96
            radius: 48
            border.width: 3
            border.color: "#ffe9b0"
            color: "#00000000"
        }
        Rectangle {
            anchors.centerIn: parent
            width: 14; height: 14
            radius: 7
            color: "#ffe9b0"
        }
    }

    Text {
        id: titleText
        text: "DESERT ORDER"
        color: "#ffe9b0"
        font.pixelSize: 42
        font.letterSpacing: 10
        font.family: "Cinzel, Georgia, serif"
        font.bold: true
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: emblem.bottom
        anchors.topMargin: 18
        opacity: 0
        NumberAnimation on opacity { id: introAnim; to: 1; duration: 1200; easing.type: Easing.OutCubic }
    }

    Rectangle {
        width: 260
        height: 1
        color: "#e8b84b"
        opacity: 0.5
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: titleText.bottom
        anchors.topMargin: 16
    }

    Text {
        text: "EGYPT — ORDER OF THE ANCIENTS"
        color: "#ff8a3d"
        font.pixelSize: 12
        font.letterSpacing: 6
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: titleText.bottom
        anchors.topMargin: 30
        opacity: 0.9
    }

    Text {
        text: {
            var msgs = [
                "awakening the animus...",
                "reading the hieroglyphs...",
                "synchronizing memories...",
                "loading the desert...",
                "restoring the order...",
                "entering Egypt..."
            ]
            return msgs[Math.min(stage, msgs.length - 1)]
        }
        color: "#e8b84b"
        font.pixelSize: 12
        font.letterSpacing: 2
        opacity: 0.75
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: dots.top
        anchors.bottomMargin: 14
    }

    Row {
        id: dots
        spacing: 14
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 60

        Repeater {
            model: stages
            Rectangle {
                width: 8
                height: 8
                radius: 4
                color: index < stage ? "#ffcf6b" : "#5a4020"
                Behavior on color { ColorAnimation { duration: 300 } }
            }
        }
    }
}
